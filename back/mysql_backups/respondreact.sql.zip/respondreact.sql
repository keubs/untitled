-- MySQL dump 10.13  Distrib 5.6.22, for osx10.10 (x86_64)
--
-- Host: localhost    Database: respondreact
-- ------------------------------------------------------
-- Server version	5.7.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address_address`
--

DROP TABLE IF EXISTS `address_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `street_number` varchar(20) NOT NULL,
  `route` varchar(100) NOT NULL,
  `raw` varchar(200) NOT NULL,
  `formatted` varchar(200) NOT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `locality_id` int(11),
  PRIMARY KEY (`id`),
  KEY `address_address_7e3ea948` (`locality_id`),
  CONSTRAINT `address_addre_locality_id_88814b5ccf6a65e_fk_address_locality_id` FOREIGN KEY (`locality_id`) REFERENCES `address_locality` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_address`
--

LOCK TABLES `address_address` WRITE;
/*!40000 ALTER TABLE `address_address` DISABLE KEYS */;
INSERT INTO `address_address` VALUES (1,'','','St Paul, MN, United States','',44.9537029,-93.0899578,NULL),(2,'','','1 Market Street, San Francisco, CA, United States','',37.7938462,-122.3948366,1),(3,'','','1 Market Street, San Francisco, CA, United States','',37.7938462,-122.3948366,1),(4,'','','1 Market Street, San Francisco, CA, United States','',37.7938462,-122.3948366,1),(5,'','','Downtown, Dallas, TX, United States','',32.7790911,-96.8002704,NULL),(6,'','','4800 Harry Hines Blvd, Dallas, TX, United States','',32.8089604,-96.8322058,2),(7,'','','Dallas, TX, United States','',32.7766642,-96.7969879,NULL),(8,'','','Baton Rouge, LA, United States','',30.4582829,-91.1403196,NULL),(9,'','','Baton Rouge, LA, United States','',30.4582829,-91.1403196,NULL),(10,'','','Dallas, TX, United States','',32.7766642,-96.7969879,NULL),(11,'','','Forsyth Road, Savannah, GA, United States','',32.0191158,-81.0862762,3),(12,'','','W 140th St, New York, NY, United States','',40.8205911,-73.9464364,NULL),(13,'','','Sudan','',12.862807,30.217636,NULL),(14,'','','Boulder County, CO, United States','',40.1512114,-105.5005483,NULL),(15,'','','San Diego, CA, United States','',32.715738,-117.1610838,NULL);
/*!40000 ALTER TABLE `address_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `code` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
INSERT INTO `address_country` VALUES (1,'United States','US'),(2,'Sudan','SD');
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_locality`
--

DROP TABLE IF EXISTS `address_locality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_locality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(165) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_locality_name_7293bc98c9f576f4_uniq` (`name`,`state_id`),
  KEY `address_locality_d5582625` (`state_id`),
  CONSTRAINT `address_locality_state_id_33e608ebb743c45a_fk_address_state_id` FOREIGN KEY (`state_id`) REFERENCES `address_state` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_locality`
--

LOCK TABLES `address_locality` WRITE;
/*!40000 ALTER TABLE `address_locality` DISABLE KEYS */;
INSERT INTO `address_locality` VALUES (1,'San Francisco','94105',2),(2,'Dallas','75235',3),(3,'Savannah','31406',5);
/*!40000 ALTER TABLE `address_locality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_state`
--

DROP TABLE IF EXISTS `address_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(165) NOT NULL,
  `code` varchar(3) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_state_name_2e4f7ffe64d1c1db_uniq` (`name`,`country_id`),
  KEY `address_state_country_id_649e81d365dbe6bc_fk_address_country_id` (`country_id`),
  CONSTRAINT `address_state_country_id_649e81d365dbe6bc_fk_address_country_id` FOREIGN KEY (`country_id`) REFERENCES `address_country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_state`
--

LOCK TABLES `address_state` WRITE;
/*!40000 ALTER TABLE `address_state` DISABLE KEYS */;
INSERT INTO `address_state` VALUES (1,'Minnesota','MN',1),(2,'California','CA',1),(3,'Texas','TX',1),(4,'Louisiana','LA',1),(5,'Georgia','GA',1),(6,'New York','NY',1),(7,'Colorado','CO',1);
/*!40000 ALTER TABLE `address_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group__permission_id_15ad0ecb32baaada_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_15ad0ecb32baaada_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_1586be7537b8279b_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth__content_type_id_4891a196eec85115_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add session',5,'add_session'),(14,'Can change session',5,'change_session'),(15,'Can delete session',5,'delete_session'),(16,'Can add token',6,'add_token'),(17,'Can change token',6,'change_token'),(18,'Can delete token',6,'delete_token'),(19,'Can add cors model',7,'add_corsmodel'),(20,'Can change cors model',7,'change_corsmodel'),(21,'Can delete cors model',7,'delete_corsmodel'),(22,'Can add topic',8,'add_topic'),(23,'Can change topic',8,'change_topic'),(24,'Can delete topic',8,'delete_topic'),(25,'Can add action',9,'add_action'),(26,'Can change action',9,'change_action'),(27,'Can delete action',9,'delete_action'),(28,'Can add vote',10,'add_vote'),(29,'Can change vote',10,'change_vote'),(30,'Can delete vote',10,'delete_vote'),(31,'Can add Tag',11,'add_tag'),(32,'Can change Tag',11,'change_tag'),(33,'Can delete Tag',11,'delete_tag'),(34,'Can add Tagged Item',12,'add_taggeditem'),(35,'Can change Tagged Item',12,'change_taggeditem'),(36,'Can delete Tagged Item',12,'delete_taggeditem'),(37,'Can add user',13,'add_customuser'),(38,'Can change user',13,'change_customuser'),(39,'Can delete user',13,'delete_customuser'),(40,'Can add user social auth',14,'add_usersocialauth'),(41,'Can change user social auth',14,'change_usersocialauth'),(42,'Can delete user social auth',14,'delete_usersocialauth'),(43,'Can add nonce',15,'add_nonce'),(44,'Can change nonce',15,'change_nonce'),(45,'Can delete nonce',15,'delete_nonce'),(46,'Can add association',16,'add_association'),(47,'Can change association',16,'change_association'),(48,'Can delete association',16,'delete_association'),(49,'Can add code',17,'add_code'),(50,'Can change code',17,'change_code'),(51,'Can delete code',17,'delete_code'),(52,'Can add country',18,'add_country'),(53,'Can change country',18,'change_country'),(54,'Can delete country',18,'delete_country'),(55,'Can add state',19,'add_state'),(56,'Can change state',19,'change_state'),(57,'Can delete state',19,'delete_state'),(58,'Can add locality',20,'add_locality'),(59,'Can change locality',20,'change_locality'),(60,'Can delete locality',20,'delete_locality'),(61,'Can add address',21,'add_address'),(62,'Can change address',21,'change_address'),(63,'Can delete address',21,'delete_address');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_t_user_id_42131046b7ac0157_fk_customuser_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `customuser_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corsheaders_corsmodel`
--

DROP TABLE IF EXISTS `corsheaders_corsmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corsheaders_corsmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cors` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corsheaders_corsmodel`
--

LOCK TABLES `corsheaders_corsmodel` WRITE;
/*!40000 ALTER TABLE `corsheaders_corsmodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `corsheaders_corsmodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customuser_customuser`
--

DROP TABLE IF EXISTS `customuser_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customuser_customuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `social_thumb` varchar(200) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customuser_customuser`
--

LOCK TABLES `customuser_customuser` WRITE;
/*!40000 ALTER TABLE `customuser_customuser` DISABLE KEYS */;
INSERT INTO `customuser_customuser` VALUES (1,'pbkdf2_sha256$20000$hqjKeqCCWFvG$703DpvQH6VWVKBxU361e5tTdeLz+Kn3kvCvdNjPIH/I=',NULL,1,'admin','Chris','Johnson','admin@test.com',1,1,'2016-07-08 23:21:58.243639','http://graph.facebook.com/10201476415109883/picture?type=normal',NULL),(2,'!rJVgSvsGL22yhcHhTbngfJb1hW58nge3mIZsKJ0A',NULL,0,'KevinCook','Kevin','Cook','kevinac4@gmail.com',0,1,'2016-07-09 03:11:26.582282','http://graph.facebook.com/10102615181971353/picture?type=normal',NULL);
/*!40000 ALTER TABLE `customuser_customuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customuser_customuser_groups`
--

DROP TABLE IF EXISTS `customuser_customuser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customuser_customuser_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customuser_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customuser_id` (`customuser_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customuser_customuser_groups`
--

LOCK TABLES `customuser_customuser_groups` WRITE;
/*!40000 ALTER TABLE `customuser_customuser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customuser_customuser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customuser_customuser_user_permissions`
--

DROP TABLE IF EXISTS `customuser_customuser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customuser_customuser_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customuser_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customuser_id` (`customuser_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customuser_customuser_user_permissions`
--

LOCK TABLES `customuser_customuser_user_permissions` WRITE;
/*!40000 ALTER TABLE `customuser_customuser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `customuser_customuser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_37b1f3fc90badaf6_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admi_user_id_1af4efb2564899bc_fk_customuser_customuser_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_37b1f3fc90badaf6_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admi_user_id_1af4efb2564899bc_fk_customuser_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `customuser_customuser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_1538405091ffff7c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (21,'address','address'),(18,'address','country'),(20,'address','locality'),(19,'address','state'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(6,'authtoken','token'),(4,'contenttypes','contenttype'),(7,'corsheaders','corsmodel'),(13,'customuser','customuser'),(16,'default','association'),(17,'default','code'),(15,'default','nonce'),(14,'default','usersocialauth'),(5,'sessions','session'),(11,'taggit','tag'),(12,'taggit','taggeditem'),(9,'topics','action'),(8,'topics','topic'),(10,'updown','vote');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'address','0001_initial','2016-07-08 23:21:45.827048'),(2,'contenttypes','0001_initial','2016-07-08 23:21:45.891863'),(3,'admin','0001_initial','2016-07-08 23:21:45.978781'),(4,'contenttypes','0002_remove_content_type_name','2016-07-08 23:21:46.040153'),(5,'auth','0001_initial','2016-07-08 23:21:46.219394'),(6,'auth','0002_alter_permission_name_max_length','2016-07-08 23:21:46.251107'),(7,'auth','0003_alter_user_email_max_length','2016-07-08 23:21:46.271780'),(8,'auth','0004_alter_user_username_opts','2016-07-08 23:21:46.287720'),(9,'auth','0005_alter_user_last_login_null','2016-07-08 23:21:46.311545'),(10,'auth','0006_require_contenttypes_0002','2016-07-08 23:21:46.316190'),(11,'authtoken','0001_initial','2016-07-08 23:21:46.377050'),(12,'default','0001_initial','2016-07-08 23:21:46.639531'),(13,'default','0002_add_related_name','2016-07-08 23:21:46.710394'),(14,'default','0003_alter_email_max_length','2016-07-08 23:21:46.749488'),(15,'sessions','0001_initial','2016-07-08 23:21:46.792504'),(16,'taggit','0001_initial','2016-07-08 23:21:46.951648'),(17,'taggit','0002_auto_20150616_2121','2016-07-08 23:21:46.990456');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_auth_association`
--

DROP TABLE IF EXISTS `social_auth_association`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_auth_association` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_url` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `issued` int(11) NOT NULL,
  `lifetime` int(11) NOT NULL,
  `assoc_type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auth_association`
--

LOCK TABLES `social_auth_association` WRITE;
/*!40000 ALTER TABLE `social_auth_association` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_auth_association` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_auth_code`
--

DROP TABLE IF EXISTS `social_auth_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_auth_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(254) NOT NULL,
  `code` varchar(32) NOT NULL,
  `verified` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_auth_code_email_20b5fb969c1df3a5_uniq` (`email`,`code`),
  KEY `social_auth_code_c1336794` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auth_code`
--

LOCK TABLES `social_auth_code` WRITE;
/*!40000 ALTER TABLE `social_auth_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_auth_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_auth_nonce`
--

DROP TABLE IF EXISTS `social_auth_nonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_auth_nonce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_url` varchar(255) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `salt` varchar(65) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_auth_nonce_server_url_47cfc37c39be1874_uniq` (`server_url`,`timestamp`,`salt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auth_nonce`
--

LOCK TABLES `social_auth_nonce` WRITE;
/*!40000 ALTER TABLE `social_auth_nonce` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_auth_nonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_auth_usersocialauth`
--

DROP TABLE IF EXISTS `social_auth_usersocialauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_auth_usersocialauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(32) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `extra_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_auth_usersocialauth_provider_3ae38199ca8fd201_uniq` (`provider`,`uid`),
  KEY `social_auth_user_id_77faae0081015bb0_fk_customuser_customuser_id` (`user_id`),
  CONSTRAINT `social_auth_user_id_77faae0081015bb0_fk_customuser_customuser_id` FOREIGN KEY (`user_id`) REFERENCES `customuser_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auth_usersocialauth`
--

LOCK TABLES `social_auth_usersocialauth` WRITE;
/*!40000 ALTER TABLE `social_auth_usersocialauth` DISABLE KEYS */;
INSERT INTO `social_auth_usersocialauth` VALUES (1,'facebook','10102615181971353','{\"expires\": null, \"id\": \"10102615181971353\", \"access_token\": \"EAAVgPVtcZB7ABAJgn5FVUGZBK0qZBziWjoeb97aMZBk7wZA1awKW7swr8US7FIdH6a02BA0ofvIKB1jGOg0oyhh77hg2Vm1BBaOmVZBWEQMYURIDFZCQ8u5uePza8BanhPEwAIiu1g79qB8UhEUeZBNCfvkewleFAdYZD\"}',2),(2,'facebook','10201476415109883','{\"access_token\": \"EAAVgPVtcZB7ABAJV8gtQmZAA1f9LwaSUpwiBNiZA8Qlmi9iwiVwCvZBaWpRCJ2vJkFFfoYWfazeXwLOZAGFc55Pw1E3MIdHpKK0ZBFIhs0MMceT8vZCeioqmKDCa3BO3nn8sCbVOOBzT8lMCNY0iRR4XDZC3C4TV9igZD\", \"id\": \"10201476415109883\", \"expires\": null}',1);
/*!40000 ALTER TABLE `social_auth_usersocialauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggit_tag`
--

DROP TABLE IF EXISTS `taggit_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggit_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggit_tag`
--

LOCK TABLES `taggit_tag` WRITE;
/*!40000 ALTER TABLE `taggit_tag` DISABLE KEYS */;
INSERT INTO `taggit_tag` VALUES (1,'police brutality','police-brutality'),(2,'philando castile','philando-castile'),(3,'rally','rally'),(4,'blm','blm'),(5,'facebook event','facebook-event'),(6,'shooting','shooting'),(7,'blood donation','blood-donation'),(8,'change.org','changeorg'),(9,'petition','petition'),(10,'alton sterling','alton-sterling'),(11,'vigil','vigil'),(12,'sudan','sudan'),(13,'darfur','darfur'),(14,'cold springs','cold-springs'),(15,'#coldsprings','coldsprings'),(16,'fire','fire'),(17,'homeless safety','homeless-safety');
/*!40000 ALTER TABLE `taggit_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggit_taggeditem`
--

DROP TABLE IF EXISTS `taggit_taggeditem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggit_taggeditem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taggit_taggeditem_tag_id_562911d48d990940_fk_taggit_tag_id` (`tag_id`),
  KEY `taggit_taggeditem_af31437c` (`object_id`),
  KEY `taggit_taggeditem_content_type_id_368a909bd5787cb8_idx` (`content_type_id`,`object_id`),
  CONSTRAINT `taggi_content_type_id_58eaf7134cfcc208_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `taggit_taggeditem_tag_id_562911d48d990940_fk_taggit_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `taggit_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggit_taggeditem`
--

LOCK TABLES `taggit_taggeditem` WRITE;
/*!40000 ALTER TABLE `taggit_taggeditem` DISABLE KEYS */;
INSERT INTO `taggit_taggeditem` VALUES (1,1,8,1),(2,1,8,2),(3,1,9,3),(4,1,9,4),(5,1,9,5),(6,2,8,6),(7,2,9,7),(8,3,9,8),(9,3,9,9),(10,3,8,1),(11,3,8,10),(12,4,9,8),(13,4,9,9),(14,5,9,3),(15,5,9,5),(16,6,9,10),(17,6,9,4),(18,7,9,3),(19,7,9,11),(20,4,8,12),(21,4,8,13),(22,5,8,16),(23,5,8,14),(24,5,8,15),(25,6,8,17);
/*!40000 ALTER TABLE `taggit_taggeditem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics_action`
--

DROP TABLE IF EXISTS `topics_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topics_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `article_link` longtext NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `start_date_time` datetime(6) DEFAULT NULL,
  `end_date_time` datetime(6) DEFAULT NULL,
  `topic_id` int(11) NOT NULL,
  `image` varchar(512) DEFAULT NULL,
  `image_url` varchar(200) NOT NULL,
  `scope` varchar(9) NOT NULL,
  `respond_react` varchar(7) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `rating_likes` int(10) unsigned NOT NULL,
  `rating_dislikes` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics_action`
--

LOCK TABLES `topics_action` WRITE;
/*!40000 ALTER TABLE `topics_action` DISABLE KEYS */;
INSERT INTO `topics_action` VALUES (1,'Rally and March Against Racist Police Terror','Justice for Alton Sterling! \nJustice for Philando Castile!\nEnd Racist Police Terror! \n----------\nFriday July 8 6pm\nJustin Herman plaza SF \n\nCo-Sponsored by:\nANSWER Coalition\nBayard Rustin Coalition\nJustice 4 Alex Nieto Coalition\nJustice 4 Mario Woods Coalition \nLatin@ Young Democrats of San Francisco\nSan Francisco Black Leadership Forum\nSan Francisco Black Lives Matter\nWest County Toxics Coalition\n----------\nPolice in Minnesota and Louisiana just killed two more Black men. The cops have murdered 562 people of color and poor people this year alone. The majority are Black men and women. These killer cops know that they will never face jail time. This is state-sanctioned terror directed against Black, Brown and poor people. Join us in the streets Friday July 8 in San Francisco to demand justice for all the victims of police brutality and end to racist police terror. \n\nAlso: Join the protest tonight, June 7th, in Oakland at 7pm at Oscar Grant Plaza. \n\nFriday July 8 6pm\nJustin Herman plaza SF \n\nCo-Sponsored by:\nANSWER Coalition\nBayard Rustin Coalition\nJustice 4 Alex Nieto Coalition\nJustice 4 Mario Woods Coalition\nLatin@ Young Democrats of San Francisco\nSan Francisco Black Leadership Forum\nSan Francisco Black Lives Matter\nWest County Toxics Coalition\n\nAll are invited to join. Please contact us to be added as a co-sponsor.','https://www.facebook.com/events/863555770455561/',1,'2016-07-09 00:01:32.678928','2016-07-09 01:00:00.000000',NULL,1,'static/image_eg4Y0Ca.jpg','https://scontent.xx.fbcdn.net/v/t1.0-0/p480x480/13619990_10209946186753646_1217907455777316984_n.jpg?oh=21f0cbdb1729df0240661eadac47a962&oe=582E1165','local',NULL,4,0,2),(2,'Red Cross asking for nationwide blood, platelet donations','The American Red Cross is asking people nationwide to donate blood and platelets after the tragedy in downtown Dallas that left five police officers dead.','http://www.wfaa.com/news/red-cross-asking-for-nationwide-blood-platelet-donations/267769349',2,'2016-07-09 03:14:24.232461',NULL,NULL,2,'static/image_fyeHykJ.jpg','http://content.wfaa.com/photo/2016/02/03/0203-Generic-Blood-Donation_1454547071022_166455_ver1.0_640_360.jpg','local',NULL,6,1,0),(3,'President Obama: Make a Speech in Chicago Addressing the Crisis of Gun Violence','After thousands of people signed Aisha and the Black Youth Project\'s petition calling on President Obama to \"come home\" to Chicago and address gun violence in his home town and other cities, the President came to Chicago on February 15th and made a speech on gun violence.\r\n\r\nThe Black Youth Project said: \"Thank you to the 49,000 individuals from across the nation that signed their name in solidarity and made their voices heard. President Obama’s speech included points with which we strongly agree, as well as points that we strongly contest. Regardless, we thank the President for answering our collective call, and we will continue to work with any and all individuals and organizations committed to combating the systemic challenges that threaten the lives of Black and Latino youth. Now that the President has come and gone, we all have work to do!\"','https://www.change.org/p/president-obama-make-a-speech-in-chicago-addressing-the-crisis-of-gun-violence',2,'2016-07-09 03:15:15.984954',NULL,NULL,2,'static/image_h5odFYQ.jpg','http://d22r54gnmuhwmk.cloudfront.net/photos/3/vy/np/OhVynpthGYLdOnr-1600x900-noPad.jpg?1423807646','national',NULL,7,0,1),(4,'Sign the petition: Justice for Alton Sterling','Tell Attorney General Loretta Lynch to bring charges against the police officers who shot and killed Alton Sterling now. Add your name.','http://petitions.moveon.org/sign/justice-for-alton-sterling?source=homepage',2,'2016-07-09 03:18:03.689731',NULL,NULL,3,'static/image_lN2KhAl.jpg','https://s3.amazonaws.com/s3.moveon.org/images/20160706_MoveOn_AltonSterling_CoC_final.png','national',NULL,9,0,0),(5,'Solidarity for Alton Sterling & Philando Castile','Alton Sterling was a Black man exicuted by the police Tuesday july 5th in the early morning for selling CDs. Come stand with us against police brutality in his honor and with others who have been victimized by the criminal injustice system.','https://www.facebook.com/events/869907533153382/',2,'2016-07-09 03:19:39.624126',NULL,NULL,3,'static/image_INzE71G.jpg','https://scontent.xx.fbcdn.net/v/t1.0-9/s720x720/13590432_605892232904217_3334305834634954279_n.png?oh=c166ff8ea137fbd8a1e2c968efb5c04a&oe=57E994EA','local',NULL,10,0,0),(6,'Alton Sterling and Castille Vigil','Our meeting will be a memorial of the recent lives lost, mourning prayer, a message, and a call to immediate action.','https://www.facebook.com/events/483882981817717/',2,'2016-07-09 03:24:17.989373',NULL,NULL,1,'static/image_H76uyGy.jpg','https://scontent.xx.fbcdn.net/t31.0-8/s720x720/13640833_1834767203413677_782789358681495559_o.jpg','local',NULL,11,2,0),(7,'Vigil for Alton Sterling, Delrawn Small, Philando Castile & Pedro Erik Villanueva','UPDATE: Due to recent events we are expanding the vigil to include #DelrawnSmall, #PhilandoCastile, #PedroErikVillanueva #GoddessDiamond & #AnthonyNuñez\n\nThis Friday June 8th we will be hosting a #VigilForAltonSterling at Fred Samuel Park in Harlem (W 140th St. and Lenox Ave.). We encourage the community to come out and participate. We will have a microphone set-up for the public to share thoughts, questions and concerns after the organizers speak. Set up will begin at 7pm for those of you who would like to show up early and lend a hand. Please share.\n\n8PM-9PM\nORGANIZERS AND SPEAKERS:\nBenjamin Gray\nNAN Youth Huddle- The National Action Network\nLesha Sekou- Founder, Street Corner Resources\nAmy Freider- Member, Jews for Racial and Economic Justice [JFREJ]]]\nGillian Curtis\n\n9PM-12AM\nPUBLIC\nCommunity Open Mic','https://www.facebook.com/events/615058425327925/',2,'2016-07-09 03:26:19.120819','2016-07-09 03:00:00.000000',NULL,1,'static/image_ziOQK0o.jpg','https://scontent.xx.fbcdn.net/v/t1.0-9/13627239_10153761796583997_5057197765719474425_n.jpg?oh=078830ea9e058452cdcf577817dfd460&oe=57FEACBF','local',NULL,12,0,0);
/*!40000 ALTER TABLE `topics_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics_topic`
--

DROP TABLE IF EXISTS `topics_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topics_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL,
  `article_link` longtext NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `image` varchar(512) DEFAULT NULL,
  `image_url` varchar(200) NOT NULL,
  `scope` varchar(9) NOT NULL,
  `address_id` int(11) DEFAULT NULL,
  `rating_likes` int(10) unsigned NOT NULL,
  `rating_dislikes` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic_created_by_id_5398b8e0a02f20f4_fk_customuser_customuser_id` (`created_by_id`),
  CONSTRAINT `topic_created_by_id_5398b8e0a02f20f4_fk_customuser_customuser_id` FOREIGN KEY (`created_by_id`) REFERENCES `customuser_customuser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics_topic`
--

LOCK TABLES `topics_topic` WRITE;
/*!40000 ALTER TABLE `topics_topic` DISABLE KEYS */;
INSERT INTO `topics_topic` VALUES (1,'Black Man Shot and Killed By Police Officer in Minnesota, Aftermath Streamed on Facebook','http://gawker.com/black-man-shot-and-killed-by-police-officer-in-minnesot-1783254573',1,'2016-07-08 23:23:07.261684','static/image_4VfGGVh.jpg','https://i.kinja-img.com/gawker-media/image/upload/s--i3XLk3bD--/c_fill,fl_progressive,g_center,h_450,q_80,w_800/nnsir3jwpmbmzeiq7vy8.png','national',1,1,0),(2,'Dallas shooting is deadliest attack for police officers since 9/11','http://www.cnn.com/2016/07/08/us/deadliest-attacks-on-police/index.html',2,'2016-07-09 03:12:04.831507','static/image_LQisTqo.jpg','http://i2.cdn.turner.com/cnnnext/dam/assets/160708011036-09-dallas-shooting-0707-car-check-large-tease.jpg','local',5,1,0),(3,'Alton Sterling shooting: Second video emerges','http://www.cnn.com/2016/07/06/us/baton-rouge-shooting-alton-sterling/',2,'2016-07-09 03:17:33.819367','static/image_e2rx2At.jpg','http://i2.cdn.turner.com/cnnnext/dam/assets/160706030340-officers-on-leave-after-fatal-shooting-wafb-dnt-00001917-large-tease.jpg','local',8,1,0),(4,'South Sudan \'back to war\', says VP Riek Machar\'s spokesman - BBC News','http://www.bbc.com/news/world-africa-36758013',2,'2016-07-10 19:03:47.115308','static/image_hxscnmg.jpg','http://ichef.bbci.co.uk/news/1024/cpsprodpb/7AD4/production/_90344413_mediaitem90344409.jpg','worldwide',13,0,0),(5,'Nearly 2,000 evacuated after Cold Springs Fire','http://www.9news.com/news/local/wildfires/wildfire-burning-in-nederland/268414723',2,'2016-07-11 05:27:09.490106','static/image_fTUnTSd.jpg','http://content.9news.com/photo/2016/07/10/IMG_1038%20_OP_1_CP__1468188391921_3904378_ver1.0_640_360.JPG','local',14,0,0),(6,'Third Victim Dies After String of Gruesome Attacks on Sleeping Homeless Men','http://gawker.com/third-victim-dies-after-string-of-gruesome-attacks-on-s-1783432340',2,'2016-07-11 05:41:27.035649','static/image_IGiYrUn.jpg','https://i.kinja-img.com/gawker-media/image/upload/s--VxNNeRjM--/c_fill,fl_progressive,g_center,h_450,q_80,w_800/so6g2khy3erh7tndxxqt.jpg','local',15,0,0);
/*!40000 ALTER TABLE `topics_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updown_vote`
--

DROP TABLE IF EXISTS `updown_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updown_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `key` varchar(32) NOT NULL,
  `score` smallint(6) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` char(15) NOT NULL,
  `date_added` datetime(6) NOT NULL,
  `date_changed` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`object_id`,`key`,`user_id`,`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updown_vote`
--

LOCK TABLES `updown_vote` WRITE;
/*!40000 ALTER TABLE `updown_vote` DISABLE KEYS */;
INSERT INTO `updown_vote` VALUES (1,8,1,'2c5504ab9a86164db22a92dc8793843d',1,2,'127.0.0.1','2016-07-09 03:16:09.057307','2016-07-09 03:16:09.057365'),(2,8,2,'2c5504ab9a86164db22a92dc8793843d',1,2,'127.0.0.1','2016-07-09 03:16:10.139024','2016-07-11 04:52:29.783858'),(3,9,3,'2c5504ab9a86164db22a92dc8793843d',-1,2,'127.0.0.1','2016-07-09 03:16:15.592011','2016-07-09 03:16:15.592058'),(4,9,2,'2c5504ab9a86164db22a92dc8793843d',1,2,'127.0.0.1','2016-07-09 03:16:16.654151','2016-07-09 03:16:16.654185'),(5,9,6,'2c5504ab9a86164db22a92dc8793843d',1,2,'127.0.0.1','2016-07-09 03:24:25.508641','2016-07-09 03:24:25.508676'),(6,9,6,'2c5504ab9a86164db22a92dc8793843d',1,1,'127.0.0.1','2016-07-09 03:24:25.847170','2016-07-09 03:24:25.847203'),(7,9,1,'2c5504ab9a86164db22a92dc8793843d',-1,2,'127.0.0.1','2016-07-09 03:24:26.182159','2016-07-09 03:24:26.182193'),(8,9,1,'2c5504ab9a86164db22a92dc8793843d',-1,1,'127.0.0.1','2016-07-09 03:24:27.051862','2016-07-09 03:24:27.051987'),(9,8,3,'2c5504ab9a86164db22a92dc8793843d',1,1,'127.0.0.1','2016-07-09 22:22:17.856536','2016-07-09 22:22:17.856601');
/*!40000 ALTER TABLE `updown_vote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-11  1:14:48
